/*
 * IteradorDeVector.cpp
 *
 *  Created on: 24 oct. 2022
 *      Author: Alumno
 */

#include "IteradorDeVector.h"

//inicio de el constructor
IteradorDeVector::IteradorDeVector(Vector &v, int posicion) {
	//inicio de constructor por defecto
	this->vector=v;
	this->actual=posicion;
}

bool IteradorDeVector::hayMasElementos(){
	return ((this->vector.getCapacidad())==this->actual);
}
item IteradorDeVector::elementoActual(){
	return this->vector.operator [](actual);
}
