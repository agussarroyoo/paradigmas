//============================================================================
// Name        : xd.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include "IteradorDeVector.h"
int main() {
	//inicio de prueba del iterador

	Vector jose;
	cin<<jose;

	IteradorDeVector iterador(jose, 0);
	cout<<"Dato"<<iterador.elementoActual()<<endl
	/*
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;*/
}
