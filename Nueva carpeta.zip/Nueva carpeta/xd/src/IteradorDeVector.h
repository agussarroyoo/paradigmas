/*
 * IteradorDeVector.h
 *
 *  Created on: 24 oct. 2022
 *      Author: Alumno
 */

#ifndef ITERADORDEVECTOR_H_
#define ITERADORDEVECTOR_H_
#include "Vector.h" //incluyo la clase a iterar
//inicio de la clase iterador
class IteradorDeVector {
private:
	const Vector &vector;
	int actual;
public:
	IteradorDeVector(Vector &v, int posicion);
	bool hayMasElementos(); //retorna si el siguiente elemento es null o no
	void avanzar(); //avanza 1 en el vector
	item elementoActual(); //devuelve el dato que esta en la posicion del vector

};

#endif /* ITERADORDEVECTOR_H_ */
