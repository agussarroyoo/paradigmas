misterio x
 |x <= 0 = 0
 |x == 1 = 1
 |otherwise = 2*x + misterio (x - 1) - 1

--La funcion recibe un numero y devuelve el resultado de elevar al cuadrado dicho numero 