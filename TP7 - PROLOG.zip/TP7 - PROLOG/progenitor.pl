maprogenitor(carlos, isabelll).
progenitor(carlos,felipe).
progenitor(william,carlos).
progenitor(george,william).
progenitor(charlotte,william).
progenitor(louis,william).
progenitor(harry,carlos).
progenitor(archie,harry).
progenitor(archie,meghan).
progenitor(lilibet,harry).
progenitor(lilibet,meghan).

masculino(carlos).
masculino(felipe).
masculino(william).
masculino(louis).
masculino(harry).
masculino(archie).
femenino(isabelll).
femenino(charlotte).
femenino(meghan).
femenino(lilibet).

padreDe(Y,X) :- progenitor(Y,X), masculino(X).
madreDe(Y,X) :- progenitor(Y,X), femenino(X).
hijaDe(Y,X) :-progenitor(X,Y), femenino(X).
hijoDe(Y,X) :-progenitor(X,Y), masculino(X).
abueloDe(X,Y) :- progenitor(X,Z), progenitor(Z,Y), masculino(Y).
abuelaDe(X,Y) :- progenitor(X,Z), progenitor(Z,Y), femenino(Y).
hermanoDe(X,Y) :- progenitor(X,Z), progenitor(Y,Z),masculino(Y).
hermanaDe(X,Y) :- progenitor(X,Z), progenitor(Y,Z),femenino(Y).
primoDe(X,Y) :- progenitor(X,Z), progenitor(Y,V), (hermanoDe(Z,V);hermanaDe(Z,V)), masculino(Y).
primaDe(X,Y) :- progenitor(X,Z), progenitor(Y,V), (hermanoDe(Z,V);hermanaDe(Z,V)) ,femenino(Y).

bisabueloDe(X,Y) :- progenitor(X,Z), abueloDe(Z,Y).


