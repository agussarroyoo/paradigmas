sumarDig(X,X):-X<10.

sumarDig(X,Y) :- X>9, Y1 is mod(X,10), X1 is X//10, sumarDig(X1,Z), Y is Y1+Z.

/* "//" REPRESENTA LA DIVISION ENTERA */

alCuadrado(X,1):- X<10, write(X).
alCuadrado(X,1):- X1 is X/10,write(X1).
alCuadrado(X,n):- X1 is X/10*n, write(X1),X2 is mod(X,10),  N1 is N-1, alCuadrado(X2,N1).