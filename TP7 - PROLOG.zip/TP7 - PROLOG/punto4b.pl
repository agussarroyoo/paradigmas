menor(X,Y) :- X<Y.

menorAmayor([]).
menorAmayor([L]).
menorAmayor([C,C1|R]) :- menor(C,C1), menorAmayor([C1|R]).

pertenecientes([],N1,N2,[]).
pertenecientes([A],N1,N2,X) :- \+ between(N1,N2,A), pertenecientes([],N1,N2,X).
pertenecientes([A],N1,N2,[A]) :- between(N1,N2,A).
pertenecientes([C|R],N1,N2,X) :-  \+ between(N1,N2,C), pertenecientes(R,N1,N2,X).
pertenecientes([C|R],N1,N2,[C|L]) :-  between(N1,N2,C), pertenecientes(R,N1,N2,L). 
/*ESTA ES UNA FORMA DE COPIAR UN ELEMENTO A OTRA LISTA*/
