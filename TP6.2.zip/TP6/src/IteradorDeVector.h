/*
 * IteradorDeVector.h
 *
 *  Created on: 22 oct. 2022
 *      Author: Agu
 */

#ifndef ITERADORDEVECTOR_H_
#define ITERADORDEVECTOR_H_
#include "Vector.h"

class IteradorDeVector {
	const Vector &vec;
	int pos;

public:
	IteradorDeVector(const Vector &v):vec(v), pos(0){};
	bool hayMasElementos() {
		return pos != vec.max;
	}
	item elementoActual() {
		return vec[pos];
	}
	void avanzar() {
		pos = pos+1;
	}
//	virtual ~IteradorDeVector();
};

#endif /* ITERADORDEVECTOR_H_ */
