/* Vector.h */

#ifndef VECTOR_H_
#define VECTOR_H_
#include <iostream>
using namespace std;

template <class item>

class Vector{
	item *arreglo;
	int max;
	bool reservarMemoria(int dim);

public:
	Vector();
	int getCapacidad();
	item &operator[](int pos)const;
	friend class IteradorDeVector;
};

template <class item>

bool Vector<item>::reservarMemoria(int dim){
	this->arreglo = new item[dim];
	if(!this->arreglo){
		cerr<<"Memoria insuficiente"<<endl;
		return false;
	}
	else
		return true;
}

template <class item>

Vector<item>:: Vector(){

	if (reservarMemoria(10))
		this->max=10;
	else
		this->max=0;
}

template <class item>

int Vector<item>:: getCapacidad(){
	return this->max;
}

template <class item>

item& Vector<item>:: operator[](int pos)const{
	if(0<=pos && pos<=this->max)
		return this->arreglo[pos];
	else{
		cerr<<"Posici�n inv�lida"<<endl;
		return this->arreglo[0];
	}
}


#endif /* VECTOR_H_ */
