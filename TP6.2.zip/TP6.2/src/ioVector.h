/* ioVector.h */

#ifndef IOVECTOR_H_
#define IOVECTOR_H_

#include <iostream>
#include "Vector.h"
using namespace std;

template<class item>
istream& operator>>(istream& entra, Vector<item> &v){
	for(int i=0; i<v.getCapacidad();i++){
		entra>>v[i];
	}
	return entra;
}
template<class item>

ostream& operator<<(ostream& sale, Vector<item> &v){
	sale<<"v [ ";
	for(int i=0; i<v.getCapacidad();i++)
		sale<<v[i]<<" ";
	sale<<"] "<<endl;
	return sale;
}
#endif /* IOVECTOR_H_ */
