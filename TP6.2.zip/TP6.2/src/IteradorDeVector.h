/*
 * IteradorDeVector.h
 *
 *  Created on: 22 oct. 2022
 *      Author: Agu
 */

#ifndef ITERADORDEVECTOR_H_
#define ITERADORDEVECTOR_H_
#include "Vector.h"


template <class x>
class IteradorDeVector {
	const Vector<int> &vec;
	int pos;
	x ok;

public:
	IteradorDeVector(const Vector<x> &v):vec(v), pos(0){};
	bool hayMasElementos() {
		return pos != vec.max;
	}
	x elementoActual() {
		return vec[pos];
	}
	void avanzar() {
		pos = pos+1;
	}
//	virtual ~IteradorDeVector();
};

#endif /* ITERADORDEVECTOR_H_ */
