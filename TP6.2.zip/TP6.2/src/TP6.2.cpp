//============================================================================
// Name        : TP3Vector.cpp
// Author      : C�tedra Paradigmas de Programaci�n - FACET - UNT
//============================================================================

#include <iostream>

#include "ioVector.h"
#include "Vector.h"
#include "IteradorDeVector.h"

using namespace std;

//COMO HAGO PARA DECLARAR INDEFINIDOS DE TIPO ITEM?


//void mostrarPositivos(Vector v);
template<class item>

bool pertenece(Vector<item> v, item x);

int main() {

	typedef int item;
	/* Creo un objeto vector */
	Vector<item> v;

	/* Muestro la informaci�n del vector recien creado */
	cout<<"Capacidad del vector: "<<v.getCapacidad()<<endl;
	cout<<"Datos del Vector (sin inicializar):"<<endl;
	cout<<v<<endl;

	/* Ingreso datos al vector por teclado*/
	cout<<"Ingrese los elementos del vector:"<<endl;
	cin>>v;

	/* Muestro el vector con los datos ingresados */
	cout<<"Datos del Vector (ingresados por teclado):"<<endl;
	cout<<v<<endl;

	/*Probamos la funcion pertenece que utiliza el iterador de vector*/
	item x;
	cout<<"Ingrese el elemento q desea buscar"<<endl;
	cin>>x;
	if(pertenece(v,x)) {
		cout<<"El elemento "<<x<<" pertenece al vector"<<endl;
	} else {
		cout<<"El elemento "<<x<<" NO pertenece al vector"<<endl;
	}

	/* Muestro el vector con los datos ingresados */
		cout<<"Datos del Vector (ingresados por teclado):"<<endl;
		cout<<v<<endl;
	/*PUNTO 4.c*/
	/* Invoco a la operacion externa mostrarPositivos que trabaja sobre una copia local del par�metro */
	//mostrarPositivos(v);

	/* Muestro por pantalla el vector luego de la invocacion a la operaci�n mostrar */
	// cout<<v<<endl;

	return 0 ;
}

//template<class item>

//void mostrarPositivos(Vector<item> v){
//	cout<<endl<<"Vector con elementos positivos"<<endl;
//	for(int i=0; i<v.getCapacidad();i++)
//		if(v[i]<=0)
//			v[i]=INDEFINIDO;
//	cout<<v<<endl;
//}
//template<class item>

//bool pertenece(Vector<item> v, item x) {
//	IteradorDeVector<item> it(v);
//	bool result = false;
//	while (it.hayMasElementos() && !result) {
//		if(it.elementoActual() == x) {
//			result = true;
//		}
//		it.avanzar();
//	}
//	return result;
//}
